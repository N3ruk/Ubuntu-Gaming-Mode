Paleta UGM: naranja intenso y azul/cian neón. UGM / N3ruk.
