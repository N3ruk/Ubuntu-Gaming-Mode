UGM-ICONS — tema final
=======================
Tema completo de iconos UGM para aplicaciones, carpetas y escritorio.
Adaptación visual: UGM / N3ruk.

Instalación recomendada: extraer todo el ZIP y ejecutar
./instalar-UGM-ICONS.sh desde la carpeta extraída.
No requiere sudo; la versión instalada anterior se conserva como copia.

Nombre interno del tema: UGM-ICONS.
Variantes normales y HiDPI. Terminal, Steam y Chrome comparten el marco UGM.
Derechos de terceros: consultar AUTHORS y COPYING.
