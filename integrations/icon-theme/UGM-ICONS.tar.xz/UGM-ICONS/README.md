# UGM-ICONS — tema final

Tema completo de iconos UGM para Linux/GNOME: aplicaciones, carpetas y elementos del escritorio. Incluye variantes normales y HiDPI. Los iconos de Steam, Google Chrome y Terminal comparten el marco UGM; Terminal usa ahora la paleta naranja/cian y está disponible también para Ptyxis, GNOME Terminal, Console y otros nombres equivalentes.

## Instalación fácil

1. Extrae **todo** el archivo `UGM-ICONS-final-2026-10-19.zip` en una carpeta.
2. Abre una terminal en esa carpeta y ejecuta:

   ```bash
   ./instalar-UGM-ICONS.sh
   ```

El instalador no necesita `sudo`. Copia el tema a `~/.local/share/icons/UGM-ICONS` (o a `$XDG_DATA_HOME/icons/UGM-ICONS`), conserva cualquier versión anterior en `UGM-ICONS-backups`, actualiza la caché y activa el tema en GNOME. Si existen, asigna los iconos especiales de Snap, Homebrew/Decky y Público mediante metadatos de GIO.

Para refrescar Nautilus si muestra iconos antiguos: `nautilus -q`.

## Instalación manual

Copia la carpeta `UGM-ICONS` completa a `~/.local/share/icons/UGM-ICONS` y activa el tema con:

```bash
gsettings set org.gnome.desktop.interface icon-theme 'UGM-ICONS'
```

## Autoría

Adaptación visual: UGM / N3ruk. Los elementos originales de terceros mantienen sus derechos y atribuciones; consulta `UGM-ICONS/AUTHORS` y `UGM-ICONS/COPYING`.
